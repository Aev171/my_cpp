#include "gui.hpp"
#include <QFileDialog>
#include <QVBoxLayout>
#include <QLabel>
#include <QFont>
#include <QToolBar>
#include <QAction>
#include <QFileInfo>
#include <QDebug>

Gui::Gui(QWidget* parent) 
    : QMainWindow(parent), mapWindow(nullptr)
{
    setupUI();
    connectSignals();
}

Gui::~Gui()
{
    if (mapWindow)
    {
        mapWindow->close();
        delete mapWindow;
    }
}

std::string Gui::getPath()
{
    return this->dropLabel->path.toStdString();
}

void Gui::setupUI()
{
    QWidget* centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    QVBoxLayout* mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->setSpacing(15);
    mainLayout->setContentsMargins(20, 20, 20, 20);
    
    QLabel* titleLabel = new QLabel("Harita Dosyası Yükleyici");
    titleLabel->setAlignment(Qt::AlignCenter);
    QFont titleFont;
    titleFont.setPointSize(16);
    titleFont.setBold(true);
    titleLabel->setFont(titleFont);
    titleLabel->setStyleSheet("color: #1976D2; padding: 10px;");
    
    dropLabel = new DropLabel(this);

    QToolBar *toolbar = addToolBar("Main Toolbar");
    toolbar->setMovable(false);

    QAction *actionOpen = new QAction("Dosya Aç", this);
    QAction *actionNew = new QAction("Yeni", this);
    
    connect(actionOpen, &QAction::triggered, this, [this]() {
        
        QString filePath = QFileDialog::getOpenFileName(
            this, 
            "Dosya seç",
            "",
            "Map Files (*.osm *.png *.pbf *.jpg *.jpeg);;All Files (*)"
        );
        
        qDebug() << "Seçilen dosya:"<< filePath;
        
        if (!filePath.isEmpty())
        {
            this->dropLabel->path = filePath;
            this->dropLabel->setText("Dosya seçildi:\n" + QFileInfo(filePath).fileName());
            onFileSelected(filePath);
        }
    });

    connect(actionNew, &QAction::triggered, this, [this]() {
        closeMapWindow();
        this->dropLabel->resetDropArea();
    });

    toolbar->addAction(actionOpen);
    toolbar->addAction(actionNew);

    mainLayout->addWidget(titleLabel);
    mainLayout->addWidget(dropLabel, 1);
    
    setWindowTitle("Map Viewer");
    resize(500, 450);
    setStyleSheet("QMainWindow { background-color: white; }");
}

void Gui::connectSignals()
{
    connect(dropLabel, &DropLabel::fileDropped, this, &Gui::onFileSelected);
}

void Gui::onFileSelected(const QString& path)
{
    if (path.isEmpty())
        return;

    dropLabel->path = path;

    if (mapWindow)
    {
        mapWindow->close();
        mapWindow = nullptr;
    }

    p = std::make_unique<parser>(path.toStdString());
    mapWindow = new MapWindow(nullptr);
    mapWindow->setParser(p.get());
    mapWindow->setAttribute(Qt::WA_DeleteOnClose);   

    connect(mapWindow, &MapWindow::windowClosed,
            this, &Gui::onMapWindowClosed);

    mapWindow->loadMapData(dropLabel->path);
    mapWindow->show();
    mapWindow->raise();
    mapWindow->activateWindow();
}
void Gui::closeMapWindow()
{
    if (mapWindow)
    {
        mapWindow->close();
        delete mapWindow;
        mapWindow = nullptr;
    }
}

void Gui::onMapWindowClosed()
{
    mapWindow->deleteLater();
    mapWindow = nullptr;
}