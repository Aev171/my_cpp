#pragma once
#include <fstream>
#include <iostream>
#include <filesystem>
#include <charconv>
#include <sqlite3.h>
#include <sstream>
#include <iomanip>
#include <unordered_set>
#include <vector>
#include <cstring>
#include <charconv>
#include <cmath>
#include <iomanip>
#include <string_view>

using namespace std;

struct node
{
    int x;
    int y;
};

struct way
{
    std::vector<node> nodeList;
    int speedL;
};

class OSMCHART
{
        const char* sql = R"(
    CREATE TABLE IF NOT EXISTS nodes (
        id      INTEGER PRIMARY KEY,
        lat     REAL,
        lon     REAL
    );

    CREATE TABLE IF NOT EXISTS ways (
        id          INTEGER PRIMARY KEY,
        speed_limit INTEGER,
        car   INTEGER
    );

    CREATE TABLE IF NOT EXISTS way_nodes (
    way_id    INTEGER,
    nd_id     INTEGER,
    order_num INTEGER,
    FOREIGN KEY (way_id) REFERENCES ways(id),
    FOREIGN KEY (nd_id)  REFERENCES nodes(id)
);
)";

    public:
    std::string d;
    OSMCHART() : stmt(nullptr), cr(0), count(0) {}

    // 2. Parametreli Constructor
    OSMCHART(const char* p_, size_t len_, std::string path_) 
        : p(p_), len(len_), path(path_), line(std::string(p_, len_)), cr(0), count(0) 
    {
        initDB();
    }

    // DB açma mantığını tek yere topla (Tekrarı önler)
    void initDB() {
        if (db != nullptr) return; // Zaten açıksa hiçbir şey yapma

        std::string db_name = filesystem::path(path).stem().string();
        std::string folder = "osm_charts/" + db_name + "/";
        std::string db_full_path = folder + db_name + ".db";

        filesystem::create_directories(folder);

        if (sqlite3_open(db_full_path.c_str(), &db) == SQLITE_OK) {
            sqlite3_exec(db, sql, nullptr, nullptr, nullptr);
            sqlite3_exec(db, "BEGIN TRANSACTION;", nullptr, nullptr, nullptr);
        }
    }

    void set(const char* p_, size_t len_, std::string path_) {
        p = p_;
        len = len_;
        path = path_;
        line = std::string(p_, len_);
        initDB(); // Eğer db null ise burada açılacak
    }
    sqlite3* getDB() { return db; }
        void LineToChart()
        {
            if (cr % 10000 == 0) { 
            sqlite3_exec(db, "COMMIT;", nullptr, nullptr,nullptr);
            sqlite3_exec(db, "BEGIN TRANSACTION;", nullptr,nullptr, nullptr);
        }
            auto get_SpeeL= [&](const char* p,size_t len,string target)
        {
            char* pos=(char*) memmem(p,len,target.c_str(),target.length());
            if (pos)
            {
                 char* eq = (char*)memmem(pos,len -(pos -p),"v=",2);
                if (eq) {
                 eq+=2;
                 if(*eq=='"')
                    eq++;
                char* quote_end = (char*)memchr(eq, '"', len - (eq - p));
                if (!quote_end) return 0;
                size_t value_len = quote_end - eq;
                std::string speed_str(eq, value_len); 
                try
                {
                    int speed = std::stoi(speed_str);
                    return speed;
                }
                catch(const std::exception& e)
                {
                    std::cerr << e.what() << '\n';
                }
                    }
            }
            return 0;
            
        };
           auto get_value = [&](std::string str, string st, bool g = false)
{
    double r=0.0;
    size_t start = st.find(str);
    if (start == std::string::npos) return 0.0;
    start = st.find('"', start) + 1;
    size_t end = st.find('"', start);
    std::string val = st.substr(start, end - start);  
    std::from_chars(val.data(),val.data()+val.size(),r);
    return r;
};
            if(memmem(p,len,"node id=",8))
            {
                cr++;
                const char* sql="INSERT INTO nodes (id,lat,lon) VALUES (?, ?, ?)";
                    sqlite3_prepare_v2(db,sql,-1,&stmt,nullptr);
                    std::string content(p,len);
                    std::cout << std::setprecision(10) << get_value("lat=", content) << std::endl;
                    sqlite3_bind_int64(stmt,1,get_value("node id=",content));
                    sqlite3_bind_double(stmt,2,get_value("lat=",content));
                    sqlite3_bind_double(stmt,3,get_value("lon=",content));
                    sqlite3_step(stmt);
                    sqlite3_reset(stmt);
                    sqlite3_finalize(stmt);
            }
            else if(memmem(p,len,"</way>",6))
            {
                cr++;
                count++;
                const char* sql1 = "INSERT OR REPLACE INTO ways (id, speed_limit, car) VALUES (?, ?, ?)";
                const char* sql2 = "INSERT OR REPLACE INTO way_nodes (way_id, nd_id, order_num) VALUES (?, ?, ?)";
                sqlite3_prepare_v2(db,sql2,-1,&stmt,nullptr);
                char* p1;
                char* p2;
                size_t i=0;
                const char* start=p;
                while(true)
                {
                    p1=(char*)memchr(p, '<', len - (p - start));
                    p2=(char*)memchr(p1,'>',len-(p1-p));
                    string content(p1+1,p2-p1-1);
                    if(content.find("ref=")!=std::string_view::npos)
                    {
                        i++;
                        sqlite3_bind_int64(stmt,1,count);
                        sqlite3_bind_int64(stmt,2,(int64_t)get_value("ref=",content,true));
                        sqlite3_bind_int64(stmt,3,i);
                        int rc = sqlite3_step(stmt);
                        sqlite3_reset(stmt);
                    if (rc != SQLITE_DONE) {
                    std::cerr << "step hatası: " << sqlite3_errmsg(db) << std::endl;
                    }
                    }
                    if (content.find("/way")!=std::string_view::npos) break;
                    p=p2+1;
                }
                sqlite3_prepare_v2(db, sql1, -1, &stmt, nullptr);
                sqlite3_bind_int64(stmt, 1, count); 
                sqlite3_bind_int(stmt, 2, get_SpeeL(start,len,"maxspeed"));
                sqlite3_bind_int(stmt, 3, is_car_road(std::string(p,len))) ? 1 : 0;
                int rc = sqlite3_step(stmt);
                if (rc != SQLITE_DONE) {
                std::cerr << "step hatası: " << sqlite3_errmsg(db) << std::endl;
                    }
                sqlite3_reset(stmt);
                sqlite3_finalize(stmt);
            }
        }
        bool is_car_road(const std::string& block) {
    static const std::unordered_set<std::string> car_roads = {
        "motorway", "trunk", "primary", "secondary",
        "tertiary", "unclassified", "residential",
        "motorway_link", "trunk_link", "primary_link",
        "secondary_link", "tertiary_link"
    };
    for (const auto& road : car_roads) {
        if (block.find(road)!= std::string::npos)
        return true;
    }
    return false;
}
 
    private:
    char* err;
    std::string line;
    std::string path;
    static sqlite3* db;
    const char* p;
    size_t len;
    sqlite3_stmt* stmt;
    int cr=0;
    int count=0;
};
