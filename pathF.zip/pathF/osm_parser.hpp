#pragma once
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <iostream>
#include <sys/stat.h>
#include <cstring>
#include <math.h>
#include <string>
#include "utm.h"
#include <functional>
#include "data.hpp"

//length = height 
struct dk
{
    int length;
    int width;
};
struct irfan
{
    double N,E;
};
class parser
{

    public:
     explicit parser(const std::string& path):p(path)
     {
     };
     void parseFile() {
    parse(p, fd, sb);
        }
    private:
    bool me=true;
    int fd;
    int r=6378;
    struct stat sb;
    std::string p;
    public:
    OSMCHART chart;
    std::string k;
    void parse(const std::string& path,int& fd,struct stat& sb)
    {
        try
        {
            fd=open(path.c_str(),O_RDONLY);
            fstat(fd,&sb);
            char*data=(char*)mmap(
                nullptr,
                sb.st_size,
                PROT_READ,
                MAP_PRIVATE,
                fd,
                0
            );
            char* p =data;
            char* end =data + sb.st_size;
            char* gt;

while (p < end)
{
    char* line_end = (char*)memchr(p, '\n', end - p);
    if (!line_end) line_end = end - 1;
    char* way_open  = (char*)memmem(p, end - p, "<way", 4);
    char* node_open = (char*)memmem(p, end - p, "<node", 5);
    char* next_gt   = (char*)memchr(p, '>', end - p);
    char* first_tag = way_open;
    if (node_open && (!first_tag || node_open < first_tag))
        first_tag = node_open;

    if (!first_tag || (next_gt && next_gt < first_tag))
    {
        if (!next_gt) break;
        size_t len = next_gt - p + 1;
        p = next_gt + 1;
        continue;
    }

    if (first_tag == way_open)
    {
        char* way_close =(char*)memmem(way_open, end - way_open,"</way>", 6);
        if (!way_close) break;
        char* block_end = way_close + 6;
        size_t len = block_end - way_open;
        chart.set(way_open, len, path);
        chart.LineToChart();
        p = block_end;
    }
    else
    {
        char* node_close = (char*)memmem(node_open, end - node_open, "/>", 2);
        if (!node_close) break;
        char* block_end = node_close + 2;
        size_t len = block_end - node_open;
        k=std::string(node_open,len);
        chart.set(node_open, len, path);
        chart.LineToChart();
        p = block_end;
    }
    sqlite3_exec(chart.getDB(), "COMMIT;", nullptr, nullptr, nullptr);
}

        }
        catch(const std::exception& e)
        {
            std::cerr << e.what() << '\n';
        }
    }
    public:
static irfan locatePoints(double lat, double lon)
{
    GridZone zone = UTM_ZONE_AUTO;
    Hemisphere hemi = HEMI_AUTO;
    double N = 0.0, E = 0.0;

    const double deg2rad = M_PI / 180.0;
    double lat_rad = lat * deg2rad;
    double lon_rad = lon * deg2rad;

    geographic_to_grid(6378137.0, 0.00669437999014, lat_rad, lon_rad, &zone, &hemi, &N, &E, nullptr, nullptr);
    return {N, E}; 
}
     dk calculate_perspective(std::string& st) 
    {
        setlocale(LC_ALL, "C");
        auto get_value= [&](const std::string& str)
        {
            size_t start=st.find(str);
            start =st.find('"',start)+1;
            size_t end=st.find('"',start);
            return std::stold(st.substr(start, end - start));
        };
        const double minlat=get_value("minlat");
        const double minlon=get_value("minlon");
        const double maxlat=get_value("maxlat");
        const double maxlon=get_value("maxlon");
        int lenght=static_cast<int>(ceil(haversine(minlat,minlon,maxlat,minlon)*1000));
        int width=static_cast<int>(ceil(haversine(minlat,minlon,minlat,maxlon)*1000));
        return {lenght,width};

    }

    static double haversine(double lat1, double lon1,
                          double lat2,double lon2)
        {
        double dLat = (lat2 - lat1) *
                      M_PI / 180.0;
         double dLon = (lon2 - lon1) * 
                      M_PI / 180.0;
        lat1 = (lat1) * M_PI / 180.0;
        lat2 = (lat2) * M_PI / 180.0;
         double a = pow(sin(dLat / 2), 2) + 
                   pow(sin(dLon / 2), 2) * 
                   cos(lat1) * cos(lat2);
        double rad = 6371;
        double c = 2 * asin(sqrt(a));
        return rad * c;
        }


};