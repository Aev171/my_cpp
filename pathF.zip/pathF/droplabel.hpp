#pragma once
#include <QLabel>
#include <QString>
#include <QMouseEvent>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QPoint>

class DropLabel : public QLabel 
{
    Q_OBJECT

public:
    explicit DropLabel(QWidget* parent = nullptr);
    QString path;
    void setupUI();
    void updateStyle(bool isDragging);
    void resetDropArea();

signals:
    void fileDropped(const QString& filePath);

protected:
    bool should_drag(QMouseEvent* event);
    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void dragEnterEvent(QDragEnterEvent* event) override;
    void dragLeaveEvent(QDragLeaveEvent* event) override;
    void dropEvent(QDropEvent* event) override;

private:
    bool dragEnable;
    QPoint m_pos;
};