#pragma once
#include "common.hpp"
#include "undo_n.hpp"

class database
{
    private:

    sqlite3 *db;
    undo_n *undo_object;
    public:

    database(const std::string& db_name)
{
    int rc = sqlite3_open(db_name.c_str(), &db);

    if (rc)
    {
        throw std::runtime_error("Dosya açılmadı");
    }
    else
    {
         undo_object = new undo_n(); 
        CreateClass("Uzantilar", "TEXT");
    }
}

    ~database()
    {
         delete undo_object;
        sqlite3_close(db);
    }

   void CreateClass(const std::string& new_class, const std::string& data_type="BLOB") 
{
    std::string sql = "CREATE TABLE IF NOT EXISTS " + new_class + " ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "filename TEXT, "
        "data " + data_type + ", "
        "mimetype TEXT"
        ");"; 

    char* error_m;

    if(sqlite3_exec(db,sql.c_str(),nullptr,nullptr,&error_m) != SQLITE_OK)
    {
        std::cout<<"Hata: "<<error_m<<std::endl;
        sqlite3_free(error_m);
        return;
    }

    try
    {

        if (!ColumnExists(db, new_class, "Note"))
        {
            AddColumn(new_class, "Note", "TEXT");
        }

       
        if (!ColumnExists(db, new_class, "Dizin"))
        {
            AddColumn(new_class, "Dizin", "TEXT");
        }

    
        if (!ColumnExists(db, new_class, "Tarih"))
        {
            AddColumn(new_class, "Tarih", "TEXT");
        }

        
        if (!ColumnExists(db, new_class, "Uzanti"))
        {
            AddColumn(new_class, "Uzanti", "TEXT");
        }

        if (!ColumnExists(db, new_class, "Boyut"))
        {
            AddColumn(new_class, "Boyut", "INTEGER");
        }

        if (!ColumnExists(db, new_class, "Isim"))
        {
            AddColumn(new_class, "Isim", "TEXT");
        }
        std::cout << "Yeni class eklendi"<<std::endl;
        undo_object->setUndo(db,"create_table","none",new_class);
        
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
}
   std::vector<char> get_file_by_column(sqlite3* db, const std::string& column, const std::string& value) {
       std::vector<char> data;
       std::string sql = "SELECT data FROM Isim WHERE " + column + " = ?";
       sqlite3_stmt* stmt;

       if (sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
           std::cerr << "SQL prepare hatası: " << sqlite3_errmsg(db) << "\n";
           return data; // boş vector döner
       }

       sqlite3_bind_text(stmt, 1, value.c_str(), -1, SQLITE_STATIC);

       if (sqlite3_step(stmt) == SQLITE_ROW) {
           const void* blob_data = sqlite3_column_blob(stmt, 0);
           int blob_size = sqlite3_column_bytes(stmt, 0);
           if (blob_data && blob_size > 0) {
               data.assign((const char*)blob_data, (const char*)blob_data + blob_size);
           }
       }
       else {
           std::cerr << "Veri bulunamadı.\n";
       }

       sqlite3_finalize(stmt);
       return data;
   }
    void print(const std::string& table, const std::string& column) {
    std::string sql = "SELECT " + column + " FROM " + table + ";";
    sqlite3_stmt* stmt;

    int rc = sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "SQL sorgusu hazırlanamadı: " << sqlite3_errmsg(db) << std::endl;
        return;
    }

    int count = 0;
    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) {
        const unsigned char* text = sqlite3_column_text(stmt, 0);
        if (text)
            std::cout << text;
        else
            std::cout << "NULL";

        count++;

        if (count % 5 == 0)
            std::cout << std::endl; 
        else
            std::cout << "   "; 
    }

    if (rc != SQLITE_DONE) {
        std::cerr << "SQL sorgusu sırasında hata: " << sqlite3_errmsg(db) << std::endl;
    }

    sqlite3_finalize(stmt);
}


    void set_name(const std::string& path, const std::string& name="default",const std::string& table="none")
    {
        if(name!="default")
        {
        Add_file_Path(table,name,"Isim");
        }

        else
        {
            std::string new_name;
         for (int i = path.length() - 1; i >= 0; i--)
         {
            new_name = std::string(1, path[i]) + new_name;
            if (path[i] == '/' || path[i] == '\\')
            {
                break;
            }
            
         }
            Add_file_Path(table,new_name,"Isim");
        }
    }


    void AddColumn(const std::string& table_n,const std::string& new_column,const std::string& column_type)
    {
        std::string sql="ALTER TABLE " + table_n + " ADD COLUMN " + new_column + " " + column_type + ";";

        char* error_m;

        int rc=sqlite3_exec(db,sql.c_str(),nullptr,nullptr,&error_m);

        if(rc!=SQLITE_OK)
        {
            std::cout<<"Hata: "<<error_m<<std::endl;
            sqlite3_free(error_m);
        }

        else
        {
            std::cout<<column_type<<" veri tipindeki "<<new_column<<" kolonu "<<table_n<<" tablosuna "<<" basariyla eklendi " <<std::endl;
            undo_object->setUndo(db,"insert_column",table_n,new_column);
            
        }
        
    }

   void Add_file_Path(const std::string& table, const std::string& path, const std::string& column = "filename")
{
    try
    {
        std::string check_sql = "SELECT rowid FROM \"" + table + "\" WHERE " + column + " = ?;";

        sqlite3_stmt* check_stmt = nullptr;

        if (sqlite3_prepare_v2(db, check_sql.c_str(), -1, &check_stmt, nullptr) != SQLITE_OK)
        {
            throw std::runtime_error("Kontrol sorgusu hazırlanamadı: " + std::string(sqlite3_errmsg(db)));
        }

        if (sqlite3_bind_text(check_stmt, 1, path.c_str(), -1, SQLITE_TRANSIENT) != SQLITE_OK)
        {
            sqlite3_finalize(check_stmt);
            throw std::runtime_error("Kontrol bind hatası: " + std::string(sqlite3_errmsg(db)));
        }

        if (sqlite3_step(check_stmt) == SQLITE_ROW)
        {
            std::cout << "[Uyarı] '" << path << "' zaten '" << table << "' tablosunun '" << column << "' sütununda mevcut! Eklenmedi.\n";
            sqlite3_finalize(check_stmt);
            return;
        }

        sqlite3_finalize(check_stmt);
        std::string sql = "INSERT INTO \"" + table + "\" (" + column + ") VALUES (?);";
        sqlite3_stmt* stmt = nullptr;

        if (sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK)
        {
            throw std::runtime_error("SQLite prepare hatası: " + std::string(sqlite3_errmsg(db)));
        }

        if (sqlite3_bind_text(stmt, 1, path.c_str(), -1, SQLITE_TRANSIENT) != SQLITE_OK)
        {
            sqlite3_finalize(stmt);
            throw std::runtime_error("SQLite bind hatası: " + std::string(sqlite3_errmsg(db)));
        }

        if (sqlite3_step(stmt) != SQLITE_DONE)
        {
            sqlite3_finalize(stmt);
            throw std::runtime_error("SQLite step hatası: " + std::string(sqlite3_errmsg(db)));
        }

        sqlite3_finalize(stmt);

        std::cout << "[Başarılı] Veri eklendi → " << column << ": " << path << std::endl;

        Add_Data_InFO(db, table, path, true);
        set_name(path,"default",table);
        undo_object->setUndo(db, "insert_path", table, path);
    }
    catch (const std::exception& e)
    {
        std::cerr << "Add_file_Path exception: " << e.what() << std::endl;
    }
}

    void Add_File_Folder(const std::string& table, const std::string& filename)
    {

        std::filesystem::path p(filename);

        try
        {

            if(std::filesystem::is_regular_file(p))
            {
                std::vector<char> data = readFileBinary(filename);
                insertSingleFile(db,table,filename,data);
                Add_Data_InFO(db,table,filename,true);
                set_name(filename,"default",table);
                undo_object->setUndo(db,"insert_file",table,filename);
        
            }

            else if (std::filesystem::is_directory(p))
            {

                for (const auto& dirEntry : std::filesystem::recursive_directory_iterator(filename))
                 {
                    std::vector<char> data = readFileBinary(dirEntry.path().string());
                    insertSingleFile(db,table,dirEntry.path().string(),data);
                    Add_Data_InFO(db,table,dirEntry.path().string(),false,filename);
                    set_name(dirEntry.path().string(),"default",table);
                    undo_object->setUndo(db,"insert_folder",table,dirEntry.path().string());

                 }
        
            }

            else
            {
                std::cerr<<"Dosya gecersiz: "<<p<<std::endl;
            }
            
            
        }
        catch(const std::exception& e)
        {
            std::cerr << e.what() << '\n';
        }

    }


    void Delete_Table(const std::string& table_n)
    {
        const std::string& sql="DROP TABLE "+ table_n +" ";
        sqlite3_stmt* stmt;
        char* error_m;

        if (sqlite3_exec(db,sql.c_str(),nullptr,nullptr,&error_m)!=SQLITE_OK)
        {
            std::cerr<<"Hata: "<<error_m<< std::endl;
            sqlite3_free(error_m);
        }
        
        else
        {
            std::cout<<table_n<<" tablosu basarilyla silindi "<<std::endl;
            vacuum_database(db);
            undo_object->setUndo(db,"drop_table","none",table_n);
        }
    }


    void delete_column(const std::string& table_n, const std::string& column_n)
    {
        std::string sql="ALTER TABLE " + table_n + " DROP COLUMN " + column_n+ ";";

        char* error_m;

        int rc=sqlite3_exec(db,sql.c_str(),nullptr,nullptr,&error_m);

        if(rc!=SQLITE_OK)
        {
            std::cerr<<"Hata: "<<error_m<<std::endl;
            sqlite3_free(error_m);
        }

        else
        {
            std::cout<< column_n<< " Kolonu basariyla silindi " <<std::endl;
            undo_object->setUndo(db,"delete_column",table_n,column_n);
            vacuum_database(db);
        }
    }

    void delete_path(const std::string& table_n,const std::string& path) //hem path 
    {
        std::string sql = "DELETE FROM " + table_n + " WHERE filename = ?";
            sqlite3_stmt* stmt;
            if (sqlite3_prepare_v2(db,sql.c_str(),-1, &stmt,nullptr) ==SQLITE_OK)
            {
                sqlite3_bind_text(stmt, 1, path.c_str(),-1,SQLITE_TRANSIENT);
                if (sqlite3_step(stmt) !=SQLITE_DONE)
                {
                    std::cerr << "Undo (insert_path) silme hatası.\n";
                }

                else
                {
                    vacuum_database(db);
                    std::cout<<"silindi";
                    undo_object->setUndo(db,"delete_path",table_n,path);
                }
                
                sqlite3_finalize(stmt);
            }
    }

    void delete_file(const std::string& table_n, const std::string& filename)
{
    std::string sql = "DELETE FROM " + table_n + " WHERE filename = ?";
    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr) == SQLITE_OK)
    {
        sqlite3_bind_text(stmt, 1, filename.c_str(), -1, SQLITE_STATIC);
        if (sqlite3_step(stmt) != SQLITE_DONE)
        {
            std::cerr << "Undo (insert_path) silme hatası.\n";
        }
        else
        {
            vacuum_database(db);
            undo_object->setUndo(db,"delete_f_f",table_n,filename);
        }
        
        sqlite3_finalize(stmt);
    }
}


    void delete_folder(const std::string& folder_n,const std::string& table_n) //bütün klasörü silmek için
    {
        std::string sql = "DELETE FROM " + table_n + " WHERE Dizin = ?";
        sqlite3_stmt* stmt;

        if (sqlite3_prepare_v2(db,sql.c_str(),-1,&stmt,nullptr)==SQLITE_OK)
        {
            sqlite3_bind_text(stmt,1,folder_n.c_str(),-1,SQLITE_TRANSIENT);
            vacuum_database(db);
            undo_object->setUndo(db,"delete_f_f",table_n,folder_n);
        }

        sqlite3_step(stmt);
        sqlite3_finalize(stmt);

    }

    void undo_()
    {
        undo_object->undo_procces(db);
    }

    
    void PrintTableContents(const std::string& table) {
    std::string sql = "SELECT rowid, * FROM " + table;
    sqlite3_stmt* stmt;
    sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        int col_count = sqlite3_column_count(stmt);
        for (int i = 0; i < col_count; ++i) {
            const char* text = (const char*)sqlite3_column_text(stmt, i);
            std::cout << sqlite3_column_name(stmt, i) << ": " << (text ? text : "NULL") << " | ";
        }
        std::cout << std::endl;
    }
    sqlite3_finalize(stmt);
}

    void FindFile(std::string& filename)
    {
        std::string sql="SELECT name FROM sqlite_master WHERE type=? ";
        std::string table="table";
        sqlite3_stmt* stmt;

        if (sqlite3_prepare_v2(db,sql.c_str(),1,&stmt,nullptr)==SQLITE_OK)
        {
            sqlite3_bind_text(stmt,1,table.c_str(),-1, SQLITE_TRANSIENT);
            
        }
        
    }

};