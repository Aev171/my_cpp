#include "mapview.hpp"
#include <QScrollBar>
#include <QMouseEvent>
#include <cmath>
#include <QGraphicsEllipseItem>
#include <QGraphicsScene>
#include <QGraphicsSceneMouseEvent>
#include <QDebug>
#include <QTimer>
#include "mapwindow.hpp"

// WaypointItem: Tıklanınca kendini silen özel nokta sınıfı

class WaypointItem : public QGraphicsEllipseItem {

public:
    WaypointItem(QPointF pos, qreal radius , bool& p, int a) //red başlangıç -- blue varış
        :QGraphicsEllipseItem(-radius, -radius, radius * 2, radius * 2), p(p) {
        setPos(pos);
        a%2==0 ? setBrush(Qt::red):setBrush(Qt::blue);
        setPen(QPen(Qt::white, 1));
        setZValue(100);
        setFlags(ItemIgnoresTransformations);
    }

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent* event) override {
        if (p) {
            scene()->removeItem(this);
            QTimer::singleShot(0, [this]() { delete this; });
        }
        event->accept(); 
    }
private:
    int count=1;
    bool& p;
};

MapView::MapView(QWidget* parent)
    : QGraphicsView(parent)
    , currentZoom(1.0)
    , minZoom(0.1)
    , maxZoom(50.0)
    , isPanning(false)
    , pressPoint(0,0)
{
    setRenderHint(QPainter::Antialiasing);
    setRenderHint(QPainter::SmoothPixmapTransform);
    setDragMode(QGraphicsView::NoDrag);
    setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
    setResizeAnchor(QGraphicsView::AnchorUnderMouse);
    setBackgroundBrush(QBrush(QColor(240, 240, 240)));
}

// --- EKSİK OLAN ZOOM FONKSİYONU ---
void MapView::zoom(double factor)
{
    double newZoom = currentZoom * factor;
    if (newZoom < minZoom || newZoom > maxZoom)
        return;
    
    scale(factor, factor);
    currentZoom = newZoom;
    emit zoomChanged(currentZoom);
}

void MapView::resetZoom()
{
    resetTransform();
    currentZoom = 1.0;
    emit zoomChanged(currentZoom);
}

void MapView::setZoomRange(double min, double max)
{
    minZoom = min;
    maxZoom = max;
}

void MapView::wheelEvent(QWheelEvent* event)
{
    double zoomFactor = 1.15;
    if (event->angleDelta().y() > 0) {
        zoom(zoomFactor);
    } else {
        zoom(1.0 / zoomFactor);
    }
    event->accept();
}

void MapView::mousePressEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton || event->button() == Qt::MiddleButton)
    {
        // Altında item var mı kontrol et
        QPointF scenePoint = mapToScene(event->pos());
        QGraphicsItem* itemUnderMouse = scene()->itemAt(scenePoint, transform());
        
        if (itemUnderMouse) {
            // Item'a eventi ilet, panning yapma
            QGraphicsView::mousePressEvent(event);
            return;
        }

        isPanning = true;
        lastPanPoint = event->pos();
        pressPoint = event->pos();
        setCursor(Qt::ClosedHandCursor);
        event->accept();
    }
    else
    {
        QGraphicsView::mousePressEvent(event);
    }
}

void MapView::mouseMoveEvent(QMouseEvent* event)
{
    if (isPanning)
    {
        QPoint delta = event->pos() - lastPanPoint;
        lastPanPoint = event->pos();
        
        horizontalScrollBar()->setValue(horizontalScrollBar()->value() - delta.x());
        verticalScrollBar()->setValue(verticalScrollBar()->value() - delta.y());
        
        event->accept();
    }
    else
    {
        QGraphicsView::mouseMoveEvent(event);
    }
}

void MapView::mouseReleaseEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton || event->button() == Qt::MiddleButton)
    {
        QPoint moveDelta = event->pos() - pressPoint;
        
        if (moveDelta.manhattanLength() < 4) 
        {
            QPointF scenePoint = mapToScene(event->pos());
            QGraphicsItem* itemUnderMouse = scene()->itemAt(scenePoint, transform());
            
            if (!itemUnderMouse) 
            {   
                if(seq==0)
                {
                    p1.x=scenePoint.x();
                    p1.y=scenePoint.y();
                }
                if(seq==1)
               {
                    p2.x=scenePoint.x();
                    p2.y=scenePoint.y();
                    point1=std::make_unique<point>(p1);
                    point2=std::make_unique<point>(p2);
                    window->getPoint(point1.get(),point2.get());
               }
                if(seq==2)
                {
                    clean=true;
                     for (QGraphicsItem* item : scene()->items())
                    {
                        if (dynamic_cast<WaypointItem*>(item))
                        {
                            scene()->removeItem(item);
                            delete item;
                        }
                    }
                    seq=0;
                }
                WaypointItem* wp = new WaypointItem(scenePoint,6,this->clean,this->seq);
                seq++;
                scene()->addItem(wp);
            }
        }

        isPanning = false;
        setCursor(Qt::ArrowCursor);
        event->accept();
    }
    else
    {
        QGraphicsView::mouseReleaseEvent(event);
    }
}