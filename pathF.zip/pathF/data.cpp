#include "data.hpp"
sqlite3* OSMCHART::db    = nullptr;