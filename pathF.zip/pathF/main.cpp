#include <QApplication>
#include "gui.hpp"
#include <clocale>

int main(int argc, char* argv[])
{
    std::setlocale(LC_NUMERIC, "C");
    QApplication app(argc, argv);

    Gui gui;

    gui.show();
    return app.exec();
}
//<bounds minlat="39.9939600" minlon="32.8062900" maxlat="40.0088800" maxlon="32.8385600"/>

