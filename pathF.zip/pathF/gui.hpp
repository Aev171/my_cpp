// gui.hpp
#ifndef GUI_HPP
#define GUI_HPP

#include <QMainWindow>
#include "droplabel.hpp"
#include "mapwindow.hpp"

class Gui : public QMainWindow
{
    Q_OBJECT

public:
    explicit Gui(QWidget* parent = nullptr);
    ~Gui();
    std::string getPath();

signals:
    void fileSelected(const QString& path);

private slots:
    void onFileSelected(const QString& path);
    void onMapWindowClosed();

private:
    void setupUI();
    void connectSignals();
    void openMapWindow(const QString& path);
    void closeMapWindow();
    
    DropLabel* dropLabel;
    MapWindow* mapWindow;
    QString& path = dropLabel->path;
    QGraphicsScene* scene;
    std::unique_ptr<parser> p;
};

#endif