#include "droplabel.hpp"
#include <QGuiApplication>
#include <QStyleHints>
#include <QDrag>
#include <QMimeData>
#include <QFont>
#include <QDebug>
#include <QFileInfo>
#include <QUrl>

DropLabel::DropLabel(QWidget* parent) 
    : QLabel(parent), dragEnable(true)
{
    setAcceptDrops(true);
    setupUI();
}

void DropLabel::setupUI()
{
    setText("Dosyayı buraya sürükleyin\n(.osm, .png, .pbf)");
    setAlignment(Qt::AlignCenter);
    setWordWrap(true);
    setMinimumSize(300, 200);
    updateStyle(false);
    
    QFont font = this->font();
    font.setPointSize(12);
    setFont(font);
}

void DropLabel::updateStyle(bool isDragging)
{
    if (isDragging)
    {
        setStyleSheet(
            "QLabel {"
            "   border: 3px dashed #259d29;"
            "   border-radius: 15px;"
            "   background-color: #E8F5E9;"
            "   color: #2E7D32;"
            "   padding: 20px;"
            "}"
        );
    }
    else if (!dragEnable)
    {
        setStyleSheet(
            "QLabel {"
            "   border: 2px solid #2196F3;"
            "   border-radius: 15px;"
            "   background-color: #E3F2FD;"
            "   color: #1565C0;"
            "   padding: 20px;"
            "}"
        );
    }
    else
    {
        setStyleSheet(
            "QLabel {"
            "   border: 2px dashed #BDBDBD;"
            "   border-radius: 15px;"
            "   background-color: #FAFAFA;"
            "   color: #616161;"
            "   padding: 20px;"
            "}"
        );
    }
}

void DropLabel::resetDropArea()
{
    dragEnable = true;
    path.clear();
    setText("Dosyayı buraya sürükleyin\n(.osm, .png, .pbf)");
    updateStyle(false);
}

bool DropLabel::should_drag(QMouseEvent* event)
{
    if (event->buttons().testFlag(Qt::LeftButton))
    {
        const int minDist = QGuiApplication::styleHints()->startDragDistance();
        return (m_pos - event->pos()).manhattanLength() > minDist;
    }
    return false;
}

void DropLabel::mousePressEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton)
    {
        m_pos = event->pos();
    }
    QLabel::mousePressEvent(event);
}

void DropLabel::mouseMoveEvent(QMouseEvent* event)
{
    if (should_drag(event) && !dragEnable && !path.isEmpty())
    {
        QDrag* drag = new QDrag(this);
        QMimeData* mimeData = new QMimeData;
        mimeData->setUrls({ QUrl::fromLocalFile(path) });
        drag->setMimeData(mimeData);
        
        drag->exec(Qt::CopyAction | Qt::MoveAction);
    }
    QLabel::mouseMoveEvent(event);
}

void DropLabel::dragEnterEvent(QDragEnterEvent* event)
{
    if (!dragEnable)
    {
        event->ignore();
        return;
    }
    
    if (event->mimeData()->hasUrls())
    {
        updateStyle(true);
        event->acceptProposedAction();
    }
    else
    {
        event->ignore();
    }
}

void DropLabel::dragLeaveEvent(QDragLeaveEvent* event)
{
    updateStyle(false);
    QLabel::dragLeaveEvent(event);
}

void DropLabel::dropEvent(QDropEvent* event)
{
    if (!event->mimeData()->hasUrls())
    {
        updateStyle(false);
        return;
    }

    QList<QUrl> urls = event->mimeData()->urls();
    bool validFile = false;
    
    for (const QUrl& url : urls)
    {
        QString filePath = url.toLocalFile();
        
        if (filePath.endsWith(".osm") || 
            filePath.endsWith(".png") || 
            filePath.endsWith(".pbf"))
        {
            path = filePath;
            validFile = true;
            dragEnable = false;
            
            setText("Dosya yüklendi:\n" + QFileInfo(filePath).fileName());
            emit fileDropped(path);
            break;
        }
    }
    
    if (validFile)
    {
        event->acceptProposedAction();
        updateStyle(false);
    }
    else
    {
        event->ignore();
        updateStyle(false);
        setText("Geçersiz dosya!\n(.osm, .png, .pbf)");
    }
}