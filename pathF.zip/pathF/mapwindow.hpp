// mapwindow.hpp
#pragma once
#ifndef MAPWINDOW_HPP
#define MAPWINDOW_HPP

#include <QWidget>
#include <QGraphicsScene>
#include <QLabel>
#include <QCloseEvent>
#include "osm_parser.hpp"
#include "road_gen.hpp"

class MapView;

class MapWindow : public QWidget
{
    Q_OBJECT

public:
    explicit MapWindow(QWidget* parent = nullptr);
    ~MapWindow();
    
    void loadMapData(const QString& path);
    void osmH();
    QGraphicsScene* getScene();
    void setParser(parser* p);
    void getPoint(point* p1,point* p2);
signals:
    void windowClosed();

protected:
    void closeEvent(QCloseEvent* event) override;
    void showEvent(QShowEvent* event) override;

private:
    MapView* mapView;
    QGraphicsScene* mapScene;
    QLabel* zoomLabel;
    parser* parser_;
    std::filesystem::path path_;
    point* p1=nullptr;
    point* p2=nullptr;
};

#endif