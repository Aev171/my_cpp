// mapwindow.cpp
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGraphicsPixmapItem>
#include <QGraphicsRectItem>
#include <QDebug>
#include <QFileInfo>
#include <QPolygon>
#include <QPointF>
#include <fstream>
#include <QPainter>
#include <QPen>
#include "mapview.hpp"

#pragma back(push,1)
struct wayPoint
{
    point start;
    point end;
    int64_t way_id;
};
#pragma pack(pop)

MapWindow::MapWindow(QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle("Harita Görünümü");
    resize(900, 700);

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);

    mapView = new MapView();
    mapView->setWindow(this);
    mapScene = new QGraphicsScene();
    mapView->setScene(mapScene);
    mapView->setZoomRange(0.09, 50);

    QWidget *infoBar = new QWidget();
    infoBar->setStyleSheet("background-color: #f5f5f5; border-top: 1px solid #ddd;");
    QHBoxLayout *infoLayout = new QHBoxLayout(infoBar);
    infoLayout->setContentsMargins(10, 5, 10, 5);

    zoomLabel = new QLabel("Zoom: 100%");
    zoomLabel->setStyleSheet("color: #666; font-size: 12px;");

    QLabel *helpLabel = new QLabel("sol tık");
    helpLabel->setStyleSheet("color: #999; font-size: 11px;");

    infoLayout->addWidget(zoomLabel);
    infoLayout->addStretch();
    infoLayout->addWidget(helpLabel);

    mainLayout->addWidget(mapView);
    mainLayout->addWidget(infoBar);

    // Zoom değişikliğini dinle
    connect(mapView, &MapView::zoomChanged, this, [this](double zoom)
            { zoomLabel->setText(QString("Zoom: %1%").arg(static_cast<int>(zoom * 100))); });
}

MapWindow::~MapWindow()
{
    delete mapScene;
}

void MapWindow::closeEvent(QCloseEvent *event)
{
    emit windowClosed();
    event->accept();
}

void MapWindow::loadMapData(const QString &path)
{
    mapScene->clear();

    qDebug() << "dosya:" << path;

    QFileInfo fileInfo(path);
    if (!fileInfo.exists())
    {
        qDebug() << "HATA: Dosya bulunamadı:" << path;
        QGraphicsTextItem *errorText = mapScene->addText("Dosya bulunamadı!");
        errorText->setDefaultTextColor(Qt::red);
        return;
    }
    path_ = path.toStdString();
    if (path.endsWith(".png", Qt::CaseInsensitive) ||
        path.endsWith(".jpg", Qt::CaseInsensitive) ||
        path.endsWith(".jpeg", Qt::CaseInsensitive))
    {
        qDebug() << "PNG/JPG dosyası yükleniyor...";

        QPixmap pixmap(path);

        if (pixmap.isNull())
        {
            qDebug() << "HATA: Pixmap yüklenemedi!";
            QGraphicsTextItem *errorText = mapScene->addText("Görsel yüklenemedi!");
            errorText->setDefaultTextColor(Qt::red);
            return;
        }

        qDebug() << "Pixmap başarıyla yüklendi, boyut:" << pixmap.size();

        QGraphicsPixmapItem *item = mapScene->addPixmap(pixmap);
        item->setTransformationMode(Qt::SmoothTransformation);

        mapScene->setSceneRect(pixmap.rect());

        mapView->fitInView(mapScene->sceneRect(), Qt::KeepAspectRatio);

        qDebug() << "Görsel başarıyla gösterildi";
    }
    else if (path.endsWith(".osm", Qt::CaseInsensitive) ||
             path.endsWith(".pbf", Qt::CaseInsensitive))
    {
        std::string a="/home/anakin/Masaüstü/dev/c++/pathF/osm_charts/"+path_.stem().string();
        if (!std::filesystem::exists(a))
        {
            parser_->parseFile();
        }
        
        osmH();
    }
    else
    {
        qDebug() << "Bilinmeyen format, demo veri gösteriliyor";

        for (int i = 0; i < 10; ++i)
        {
            for (int j = 0; j < 10; ++j)
            {
                mapScene->addRect(
                    i * 100, j * 100, 90, 90,
                    QPen(Qt::gray),
                    QBrush(QColor(200 + i * 5, 200 + j * 5, 220)));
            }
        }
        mapScene->setSceneRect(0, 0, 1000, 1000);
        mapView->fitInView(mapScene->sceneRect(), Qt::KeepAspectRatio);
    }
}

void MapWindow::osmH()
{
    mapView->setTransform(QTransform().scale(1, -1));
    std::string baseName = path_.stem().string();
    std::string dbPath = "/home/anakin/Masaüstü/dev/c++/pathF/osm_charts/" + baseName + "/" + baseName + ".db";
    std::string wayPath = "/home/anakin/Masaüstü/dev/c++/pathF/osm_charts/" + baseName + "/" + baseName+".bin";
    sqlite3 *db;
    if (sqlite3_open(dbPath.c_str(), &db) != SQLITE_OK) return;

    sqlite3_stmt *stmt;
    std::string sql = "SELECT way_id, order_num, lat, lon FROM way_nodes JOIN nodes ON way_nodes.nd_id = nodes.id ORDER BY way_id, order_num";
    if(sqlite3_prepare_v2(db, "SELECT COUNT(DISTINCT way_id) FROM way_nodes", -1, &stmt, nullptr)!=SQLITE_OK) return;
    
    sqlite3_step(stmt);
    int count = sqlite3_column_int(stmt, 0);
    sqlite3_finalize(stmt);
    size_t expected_size=sizeof(wayPoint)*count;

    qDebug() << "way count:" << count; 
    struct stat sb;

    int fd=open(wayPath.c_str(),O_RDWR | O_CREAT| O_TRUNC,0644);
    ftruncate(fd,expected_size);
    

    void* ptr = mmap(
        nullptr, // adres 
        expected_size,   // boyut
        PROT_READ | PROT_WRITE, // okuma + yazma
        MAP_SHARED, // diske yansısın
        fd, // dosya
        0 );// offset
    wayPoint* data=static_cast<wayPoint*>(ptr);
    wayPoint point1;

    if (sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) return;

    QPainterPath allPaths;
    int lastWayId = -1;
    int idx=-1;
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        int way_id = sqlite3_column_int64(stmt, 0);
        double lat = sqlite3_column_double(stmt, 2);
        double lon = sqlite3_column_double(stmt, 3);
        auto point = parser_->locatePoints(lat, lon);
        QPointF p(point.E, point.N);
        if (way_id != lastWayId) {
            if (idx != -1) data[idx] = point1;
            idx++;
            allPaths.moveTo(p);
            point1.way_id=way_id;
            point1.start.x=p.x();
            point1.start.y=p.y();
            lastWayId = way_id;
        } else {
            allPaths.lineTo(p);
        }
        point1.end.x=p.x();
        point1.end.y=p.y();
        qDebug()<<point1.start.x;
        qDebug()<<point1.start.y;
        qDebug()<<point1.end.x;
        qDebug()<<point1.end.y;
        qDebug()<<point1.way_id;
        
    }
    if (idx != -1) data[idx] = point1; 
    msync(ptr, expected_size, MS_SYNC);
    munmap(ptr,expected_size);
    ::close(fd);
    QPen pen(Qt::blue, 0); 
    pen.setCosmetic(true); 

    mapScene->clear(); 
    mapScene->addPath(allPaths, pen);
    mapScene->setSceneRect(allPaths.boundingRect());
    mapView->fitInView(allPaths.boundingRect(), Qt::KeepAspectRatio);

    sqlite3_finalize(stmt);
    sqlite3_close(db);
}

QGraphicsScene *MapWindow::getScene()
{
    return mapScene;
}

void MapWindow::setParser(parser *p)
{
    parser_ = p;
}
void MapWindow::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);
    if (!mapScene->items().isEmpty())
        mapView->fitInView(mapScene->sceneRect(), Qt::KeepAspectRatio);
}

void MapWindow::getPoint(point* point1,point* point2)
{
    p1=point1;
    p2=point2;

}

