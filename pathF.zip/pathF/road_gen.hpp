#pragma once
#include <iostream>
#include "osm_parser.hpp"
class road_point_saver
{
    road_point_saver(int fd,size_t size):fd(fd),size(size)
    {
        
    }



    private:
    int fd;
    size_t size;
};

struct point
{
    int x;
    int y;
};

class adam
{
    adam(std::string path,point p1, point p2)
    {}
};
