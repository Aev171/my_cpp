#ifndef MAPVIEW_HPP
#define MAPVIEW_HPP

#include <QGraphicsView>
#include <QWheelEvent>
#include <QMouseEvent>
#include "road_gen.hpp"
#include "mapwindow.hpp"

class MapWindow;

class MapView : public QGraphicsView
{
    Q_OBJECT

public:
    explicit MapView(QWidget* parent = nullptr);
    void zoom(double factor);
    void setZoomRange(double minZoom, double maxZoom);
    void resetZoom();
    double getCurrentZoom() const { return currentZoom; }
    void setWindow(MapWindow* w) { window = w; }

signals:
    void zoomChanged(double zoomLevel);
    void pointsReady(point x, point y);

protected:
    void wheelEvent(QWheelEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void mouseReleaseEvent(QMouseEvent* event) override;

private:
    double currentZoom;
    double minZoom;
    double maxZoom;
    QPoint lastPanPoint; 
    QPoint pressPoint;   // Başlangıç noktasını tutan tek tanım
    bool isPanning;
    QVector<QPointF> waypointList;
    int seq=0;
    bool clean=false;
    point p1;
    point p2;
    MapWindow* window=nullptr;
    std::shared_ptr<point> point1 = std::make_shared<point>();
    std::shared_ptr<point> point2 = std::make_shared<point>();
};

#endif